##### Graph Exercises 1 #####

##### Solution 1 #####

# Installing ggplot2
install.packages("lazyeval")
install.packages("ggplot2")

# Loading ggplot2
library("ggplot2")

# Using given data
data = c(179718,41370,41914,44280)
data1 = c("Army","Navy","Air Force","Marines")

# Creating dataframe
df <- data.frame(Category = data1, Value = data)

# Converting Category variable to factor
df$Category = as.character(df$Category)
df$Category = factor(df$Category, levels = unique(df$Category))

# Adding addition columns, needed for drawing with geom_rect.
df$fraction = df$Value / sum(df$Value)
df = df[order(-df$fraction), ]
df$ymax = cumsum(df$fraction)
df$ymin = c(0, head(df$ymax, n=-1))

# Creating Donut Chart

ggplot(df, aes(fill=Category, ymax=ymax, ymin=ymin, xmax=5, xmin=3)) +
  geom_rect() +
  coord_polar(theta="y") +
  scale_fill_manual("",values = c("red", "Green","sky blue","purple")) +
  xlim(c(0, 5)) +
  guides(fill=FALSE) +
  theme(panel.grid=element_blank()) +
  theme(axis.text=element_blank()) +
  theme(axis.title=element_blank(),axis.ticks=element_blank()) +
  theme(panel.border=element_rect(fill=NA)) +
  geom_text(aes(label=paste(Category , round(fraction*100,2),"%"),x=4.0,y=(ymin+ymax)/2),size = 4) +
  annotate("text", x = 0, y = 0, label = "Traumatic Brain Injury: 2000-2014",size = 6) +
  labs(title="")


##### Solution 2 #####

# Reading "iraqbdc.csv" from local
fname <- file.choose()
idata <- read.csv(fname,header = TRUE)

# Ordering years in decresing order
idata = idata[order(-idata$years), ]

# Converting years variable to factor
idata$years <- as.character(idata$years)
idata$years <- factor(idata$years , levels = unique(idata$years))


install.packages("scales")
# Loading packages
library("reshape")
library("ggplot2")
library("plyr")
library("scales")

# Reshaping data
idata_m <- melt(idata)


# Creating Heat map

ggplot(idata_m, aes(variable, years)) + 
  theme_bw() +
  geom_tile(aes(fill = value),colour = "white") + 
  scale_fill_gradientn(colours=c("steelblue","light yellow","red"), rescale(c(min(idata_m$value),max(idata_m$value)/2, max(idata_m$value)))) +
  theme(axis.title=element_blank(),axis.ticks=element_blank()) +
  theme(legend.title=element_blank(),panel.grid  = element_blank(),panel.border = element_blank()) +
  labs(title = "Iraq Body Count",size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_y_discrete(position = "right") 
   

##### Solution 3 #####

# Installing required packages

install.packages("tm")
install.packages("wordcloud")
install.packages("RColorBrewer")

# Loading required packages
library("tm")
library("wordcloud")
library("RColorBrewer")

# Given text
text = "I also want to thank all the members of Congress and my administration who are here today for the wonderful work that they do. I want to thank Mayor Gray and everyone here at THEARC for having me.."

# Creating Corpus 
text1 <- Corpus(VectorSource(text))

# Strng Cleaning
text_data<-tm_map(text1,stripWhitespace)
text_data<-tm_map(text_data,tolower)
text_data<-tm_map(text_data,removeNumbers)
text_data<-tm_map(text_data,removePunctuation)
text_data<-tm_map(text_data,removeWords, stopwords("english"))

# Creating word cloud
wordcloud(text_data, scale=c(1.5,2), max.words=100, random.order=FALSE, rot.per=0.50, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
