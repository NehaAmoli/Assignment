##### Graph Exercises 2 #####

##### Solution 1 #####

# Reading the csv

fname <- file.choose()
chlmort <- read.csv(fname,header = TRUE)

# Plotting Scatter plot

plot(chlmort$gdp_bil,chlmort$child, xlab = "GDP in billions in current US$",
     ylab = "Child Mortality Rate",
     main = "Child Mortality Rate in selected countries for 2012",
     col= "purple",
     pch = 16)
abline(h=mean(chlmort$child),col = "red")
text(x=3500,y = 50, labels = "Average Child Mortality",col = "red")
#text(x=max(chlmort$gdp_bil),y = chlmort[which(chlmort$gdp_bil == max(chlmort$gdp_bil)),"child"] + 10, labels = chlmort[which(chlmort$gdp_bil == max(chlmort$gdp_bil)),"CountryName"],col = "black")
#text(x=min(chlmort$gdp_bil),y = chlmort[which(chlmort$gdp_bil == min(chlmort$gdp_bil)),"child"] + 10, labels = chlmort[which(chlmort$gdp_bil == min(chlmort$gdp_bil)),"CountryName"],col = "black")

##### Solution 2 #####

fname <- file.choose()
disable <- read.csv(fname,header = TRUE)

data <- data.frame(position = as.character(disable$position),player = as.character(disable$player),start = as.POSIXct(disable$start),end = as.POSIXct(disable$end))

# Installing package
install.packages("googleVis")

# Loading package
library("googleVis")

# Plotting gantt chart
dis = gvisTimeline(data = data, rowlabel = "position", start = "start", end = "end",barlabel = "player",options = list(width = 1000,height = 900, timeline = "{singleColor : '#002A3E'}"))
plot(dis) # http://127.0.0.1:29949/custom/googleVis/TimelineID28445c4442b9.html


##### Solution 3 #####

# Reading "crimeUSA.csv" file
fname <- file.choose()
crime <- read.csv(fname,header = TRUE)

# Loading "googleVis" package
library("googleVis")

# Plotting Bubble chart

Bubble <- gvisBubbleChart(crime, idvar="States", 
                          xvar="Robbery", yvar="Burglary",
                          sizevar="Population",colorvar="Year",
                          options=list(legend = 'none',width = 1000,height = 600,vAxes="[{title:'Burglary'}]",hAxes="[{title:'Robbery'}]",title = "Crime per state in 2012"
                           )) 
plot(Bubble) # http://127.0.0.1:29949/custom/googleVis/BubbleChartID2844783b3857.html

##### Solution 4 #####

fname <- file.choose()
infant <- read.csv(fname,header = TRUE)

# Ordering "Total2011" column
infant <- infant[order(-infant$Total2011),]

# Plotting Barplot 

par(mar=c(10, 4, 4, 2) + 0.1)
barplot(infant$Total2011,
        main = "Infant Mortality Rate of India in 2011",
        ylim=c(0,20),
        names.arg = infant$India,
        col = "orange",las=2)

