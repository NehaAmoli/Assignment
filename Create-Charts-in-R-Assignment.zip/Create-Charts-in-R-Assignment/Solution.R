################## Solution 1 ####################################

# Reading R File
data <- read.csv("C:\\Users\\ne304785\\Downloads\\waterfall_charts_trng_project\\waterfall.csv",header = T)

# Converting "labels" variable to factor
data$labels <- as.character(data$labels)
levels<-data$labels
data$labels <- factor(data$labels,levels = levels)

# Creating "id" variable
data$id <- c(1:dim(data)[1])

# Creating "type" varibale
data$type <- ifelse(data$value > 0, "in","out")
data[which(data$logic == TRUE),"type"] <- "net"

# Creating "end" and "start" variable
data$end <- cumsum(data$value)
data[length(data$type),"end"]<-0
data$start <- 0
data[2:(length(data$end)),"start"] <- data[1:(length(data$end)-1),"end"]


# Converting "type" variable to factor
data$type <- as.factor(data$type)

# Creating "max" variable for data labels over bar
max <- c()
for(i in 1:dim(data)[1]){
  max1 <- max(data[i,"start"],data[i,"end"]) + 1
  max<- c(max,max1)
}

# Installing "ggplot2"
install.packages("lazyeval")
install.packages("ggplot2")

# Loading the package "ggplot2"
library("ggplot2")

# Creating Waterfall chart

ggplot(data,aes(labels,fill= type))+
  geom_rect(aes(x =labels,xmin=id-0.45,xmax=id+0.45,ymin=end,ymax=start)) + 
  geom_text(aes(x=labels, y= max,  label=value, hjust=ifelse(sign(value)>0, 1, 0)), position = position_dodge(width=1)) +
  ggtitle("Waterfall Plot Showing Financial Data")+theme(plot.title = element_text(hjust = 0.5)) + 
  guides(fill=FALSE)+scale_fill_manual(values = c("blue","green","red")) +
  theme(axis.title = element_blank())



################## Solution 2 ####################################

data = c(179718,41370,41914,44280)
data1 = c("Army","Navy","Air Force","Marine")

# Creating dataframe
df = data.frame(Category = data1 , Value = data)

# Converting "Category" variable as factor 
df$Category <- as.character(df$Category)
df$Category <- factor(df$Category , levels = unique(df$Category))

# Creating Pie Chart

ggplot(df, aes(x = "", y = Value, fill = Category)) + 
  theme_bw() + 
  geom_bar(width = 1, stat = "identity") +
  scale_fill_manual("",values = c("red", "blue","Green","Yellow")) +
  coord_polar("y", start = pi+pi/4) +
  labs(title = "Traumatic Brain Injury 2000-2014(Q2)") +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(axis.title=element_blank(),axis.text = element_blank(),axis.ticks = element_blank(),panel.grid  = element_blank(),panel.border = element_blank())+
  geom_text(aes(label = paste(round(Value/sum(Value)*100,2),"%")), position = position_stack(vjust = 0.5)) +
  theme(legend.position = "left")